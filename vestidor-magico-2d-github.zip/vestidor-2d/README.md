# Vestidor mágico 2D

Proyecto web sencillo para GitHub Pages. Incluye la ilustración original en `assets/personaje.gif` y un selector de ropa por temporadas, celebraciones y pijamas.

## Ejecutar
Abre `index.html` en un navegador. Para publicarlo, sube todos los archivos al repositorio y activa GitHub Pages desde **Settings → Pages**.

## Personalización
Los conjuntos están definidos en `script.js`, dentro del objeto `looks`. Los trazos SVG son una base aproximada y editable: para que la ropa calce perfectamente con la ilustración, crea capas PNG/SVG transparentes a la medida y reemplaza las rutas de `garment()`. La imagen original permanece como capa inferior, sin alterar su rostro, cabello ni accesorios.
