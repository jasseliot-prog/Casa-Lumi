// Vestidor 2D: la imagen original se mantiene intacta y se dibujan capas de ropa encima.
// Los trazos son una base editable; ajusta sus coordenadas para calzar con tu ilustración.
const looks = {
  invierno: [
    {name:"Abrigo de ciruela",desc:"Bufanda y pantalón abrigado",top:"#68418e",pants:"#302044",accent:"#e4b8ff",kind:"coat"},
    {name:"Suéter lavanda",desc:"Tejido calentito",top:"#a77bd0",pants:"#49315f",accent:"#f3d9ff",kind:"sweater"},
    {name:"Invierno estrellado",desc:"Azul noche con estrellas",top:"#273c79",pants:"#22264d",accent:"#c7d8ff",kind:"sweater"}
  ],
  verano: [
    {name:"Conjunto de verano",desc:"Polera fresca y shorts",top:"#ff9dba",pants:"#7ccfd0",accent:"#fff0a8",kind:"summer"},
    {name:"Día soleado",desc:"Colores alegres",top:"#ffd05e",pants:"#f18a9b",accent:"#fff7cf",kind:"summer"}
  ],
  primavera: [
    {name:"Jardín de flores",desc:"Rosa y verde suave",top:"#f4a6c8",pants:"#8ebc9b",accent:"#fff1a8",kind:"spring"},
    {name:"Lavanda primaveral",desc:"Lila con detalles florales",top:"#b99ae8",pants:"#a8a1d8",accent:"#fff0fb",kind:"spring"}
  ],
  otono: [
    {name:"Hojas de otoño",desc:"Suéter terracota",top:"#b85f3f",pants:"#70452f",accent:"#f6c77b",kind:"sweater"},
    {name:"Canela",desc:"Mostaza y café",top:"#c58b32",pants:"#59402f",accent:"#f5d79a",kind:"sweater"}
  ],
  navidad: [
    {name:"Navidad clásica",desc:"Rojo, verde y dorado",top:"#b82e48",pants:"#23634c",accent:"#f5d47b",kind:"holiday"},
    {name:"Hada de nieve",desc:"Blanco y celeste",top:"#d8e9ff",pants:"#829cc8",accent:"#fff7cf",kind:"holiday"}
  ],
  fiestas: [
    {name:"Fiestas Patrias",desc:"Blanco, azul y rojo",top:"#fff4f0",pants:"#244b91",accent:"#d84b5b",kind:"chile"},
    {name:"Cueca festiva",desc:"Rojo con detalles blancos",top:"#d94c5a",pants:"#f2eee9",accent:"#244b91",kind:"chile"}
  ],
  "ano-nuevo": [
    {name:"Brillo de medianoche",desc:"Dorado y negro",top:"#d5ad55",pants:"#282035",accent:"#fff0b2",kind:"party"},
    {name:"Noche plateada",desc:"Plata y violeta",top:"#c9c9e8",pants:"#5b477c",accent:"#fff",kind:"party"}
  ],
  "san-valentin": [
    {name:"Corazones",desc:"Rosa y rojo",top:"#f18bb6",pants:"#b94d76",accent:"#ffe6f1",kind:"love"},
    {name:"Dulce amor",desc:"Lila y rosa pastel",top:"#c7a4ee",pants:"#e9a5c9",accent:"#fff0f7",kind:"love"}
  ],
  "pijama-verano": [
    {name:"Pijama de verano",desc:"Conjunto ligero",top:"#8bd4d0",pants:"#f6b4d0",accent:"#fff3a9",kind:"pajama"},
    {name:"Pijama de lunas",desc:"Fresco y celestial",top:"#697fc4",pants:"#879bd9",accent:"#fff0b2",kind:"pajama"}
  ],
  "pijama-invierno": [
    {name:"Pijama calentito",desc:"Enterito suave",top:"#9c79c7",pants:"#76559e",accent:"#f4d9ff",kind:"coat"},
    {name:"Pijama de ositos",desc:"Cómodo y abrigado",top:"#b77b91",pants:"#8d627d",accent:"#ffe5ee",kind:"coat"}
  ]
};

const svg = document.getElementById("ropa");
const list = document.getElementById("conjuntos");
const tabs = [...document.querySelectorAll("[data-cat]")];
let category = "invierno";
let selected = 0;

function garment(look) {
  const {top,pants,accent,kind} = look;
  const sleeve = kind === "summer" ? "" : `
    <path d="M176 207 Q158 207 146 225 L133 267 Q131 276 143 281 L160 286 L178 248 Z"
      fill="${top}" stroke="#21152f" stroke-width="3"/>
    <path d="M278 207 Q294 209 305 228 L317 267 Q319 277 307 282 L291 286 L276 248 Z"
      fill="${top}" stroke="#21152f" stroke-width="3"/>`;
  const torso = kind === "summer"
    ? `<path d="M183 204 Q202 193 222 198 Q249 193 273 207 L283 287 Q259 305 218 303 Q184 302 168 285 Z" fill="${top}" stroke="#21152f" stroke-width="3"/>`
    : `<path d="M181 204 Q202 194 222 198 Q250 194 275 207 L284 291 Q258 307 219 305 Q183 303 167 287 Z" fill="${top}" stroke="#21152f" stroke-width="3"/>`;
  const legs = kind === "summer"
    ? `<path d="M165 291 Q194 294 219 299 L213 330 Q180 328 151 320 Z M221 299 Q258 292 284 291 L300 321 Q265 332 229 330 Z" fill="${pants}" stroke="#21152f" stroke-width="3"/>`
    : `<path d="M145 300 Q180 291 219 303 Q220 326 202 349 Q179 367 139 357 Q120 350 124 330 Z M220 303 Q260 290 293 300 Q322 316 328 338 Q331 355 307 362 Q270 372 235 351 Q215 335 220 303 Z" fill="${pants}" stroke="#21152f" stroke-width="3"/>`;
  let decoration = "";
  if (kind === "chile") decoration = `<path d="M220 202 L220 300" stroke="${accent}" stroke-width="5"/><path d="M191 220 L205 228 M249 220 L263 228" stroke="${accent}" stroke-width="4"/>`;
  else if (kind === "love") decoration = `<path d="M220 236 C208 222 192 240 220 259 C248 240 232 222 220 236Z" fill="${accent}"/>`;
  else if (kind === "holiday") decoration = `<path d="M194 225 l7 10 12-2 -8 9 3 12 -14-7 -11 7 3-12 -8-9 12 2Z" fill="${accent}"/>`;
  else decoration = `<path d="M220 230 C208 230 207 248 220 258 C233 248 232 230 220 230Z" fill="${accent}" opacity=".9"/>`;
  return `${legs}${sleeve}${torso}${decoration}
    <path d="M183 292 Q220 302 275 292" fill="none" stroke="${accent}" stroke-width="2.5" opacity=".8"/>
    <circle cx="194" cy="276" r="3" fill="${accent}"/><circle cx="245" cy="277" r="3" fill="${accent}"/>`;
}

function render() {
  const options = looks[category];
  list.innerHTML = "";
  options.forEach((look,i) => {
    const b = document.createElement("button");
    b.className = "item" + (i === selected ? " active" : "");
    b.innerHTML = `<strong>${look.name}</strong><span>${look.desc}</span>`;
    b.addEventListener("click", () => { selected = i; render(); });
    list.appendChild(b);
  });
  svg.innerHTML = garment(options[selected]);
}
tabs.forEach(btn => btn.addEventListener("click", () => {
  category = btn.dataset.cat; selected = 0;
  tabs.forEach(t => t.classList.toggle("active", t === btn));
  render();
}));
render();
